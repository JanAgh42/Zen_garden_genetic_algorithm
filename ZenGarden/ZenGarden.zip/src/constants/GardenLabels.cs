namespace ZenGarden.src.constants
{
    enum GardenLabels
    {
        EMPTY = '-',
        LEAF = 'L',
        STONE = 'S',
        RAKED = 'R',
        PERIM = 'P'
    }
}