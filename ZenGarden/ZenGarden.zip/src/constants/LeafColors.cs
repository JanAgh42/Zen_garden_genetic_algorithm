namespace ZenGarden.src.constants
{
    enum LeafColors
    {
        YELLOW = '1',
        ORANGE,
        RED
    }
}