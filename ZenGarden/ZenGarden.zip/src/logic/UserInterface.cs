using ZenGarden.src.models;

namespace ZenGarden.src.logic
{
    class UserInterface
    {
        public GeneticAlgorithm Algorithm { get; private set; } = null!;

        public UserInterface()
        {
            InitializeExecution();
        }

        private void InitializeExecution()
        {
            string choice;

            do
            {
                Console.WriteLine("-------------------------");
                Console.WriteLine("12_10_6 15_15_10 6_6_2");
                Console.WriteLine("-------------------------");
                Console.Write("Enter filename without '.txt' or 'exit': ");

                choice = Console.ReadLine();

                switch (choice)
                {
                    case "12_10_6":
                    case "15_15_10":
                    case "6_6_2":
                    case "9_13_5":
                        AutoTesting(choice); break;
                    case "exit": break;
                    default:
                        Console.WriteLine("Invalid input.");
                        break;
                }

            } while(choice != "exit");
        }

        private void AutoTesting(string filename)
        {
            var stones = new List<(int, int)>();

            var info = filename.Split("_");

            int width = Convert.ToInt32(info[0]);
            int height = Convert.ToInt32(info[1]);

            Console.WriteLine("-------------------------");
            Console.Write("Enter number of generations: ");

            int generations = Convert.ToInt32(Console.ReadLine());

            foreach (string line in System.IO.File.ReadLines(@"./src/inputs/" + filename + ".txt"))
            {
                var coords = line.Split("_");
                stones.Add((Convert.ToInt32(coords[0]), Convert.ToInt32(coords[1])));
            }

            Algorithm = new GeneticAlgorithm(width + 2, height + 2, stones);

            Algorithm.ComputeFitness();

            for (int x = 0; x < generations; x++)
            {
                Algorithm.Monk.CreateNewGeneration();
                Algorithm.ComputeFitness();
            }

            foreach (Chromosome c in Algorithm.Monk.Chromosomes)
            {
                Console.WriteLine(c.FitnessValue);
            }

            Console.WriteLine("***********************************");
            Algorithm.Garden.PrintGarden();
            Console.WriteLine("***********************************");
            Console.WriteLine("Number of generations: " + generations);
            Console.WriteLine("Fitness value: " + Algorithm.Monk.MaxFitness);
            Console.WriteLine("***********************************");
        }
    }
}