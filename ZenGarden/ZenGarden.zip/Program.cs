﻿using ZenGarden.src.logic;

namespace ZenGarden
{
    class Program
    {
        static void Main(string[] args)
        {
            UserInterface UI = new UserInterface();
        }
    }
}